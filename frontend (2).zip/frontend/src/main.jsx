import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { Provider } from 'react-redux'
import { QueryClientProvider } from '@tanstack/react-query'
import { BrowserRouter } from 'react-router-dom'
import { store } from './store/store'
import { queryClient } from './api/queryClient'
import AuthBootstrap from './features/auth/AuthBootstrap'
import App from './App'
import './index.css'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Provider store={store}>
      <QueryClientProvider client={queryClient}>
        <AuthBootstrap>
          <BrowserRouter>
            <App />
          </BrowserRouter>
        </AuthBootstrap>
      </QueryClientProvider>
    </Provider>
  </StrictMode>,
)